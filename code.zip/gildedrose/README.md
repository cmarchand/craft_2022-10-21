# Gilded Rose

This code allows to update informations on items sold in Gilded Rose Shop.

In this kata, the model **must not** be modified. i.e. the class `Item` must not be changed.

The purpose is to allow to add new rules for a new item type, without modifying existing rules.
