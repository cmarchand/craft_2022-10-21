import java.util.Arrays;
import java.util.function.Consumer;

public class Rover {

    private String direction;
    private int y;
    private int x;

    public Rover(int x, int y, String direction) {
        this.x = x;
        this.y = y;
        this.direction = direction;
    }

    private void moveOneCommand(String command) {
        CommandStrategy.of(command).move(this);
    }

    public String move(String command) {
        for (int i = 0; i < command.length(); i++) {
            moveOneCommand(Character.toString(command.charAt(i)));
        }
        return String.format("%d %d %s", x, y, this.direction);
    }

    private enum CommandStrategy {
        FORWARD("F", rover -> DirectionStrategy.of(rover.direction).forward(rover)),
        BACKWARD("B", rover -> DirectionStrategy.of(rover.direction).backward(rover)),
        LEFT("L", rover -> DirectionStrategy.of(rover.direction).left(rover)),
        RIGHT("R", rover -> DirectionStrategy.of(rover.direction).right(rover));

        private final String code;
        private final Consumer<Rover> mover;

        CommandStrategy(String code, Consumer<Rover> mover) {
            this.code = code;
            this.mover = mover;
        }

        public static CommandStrategy of(String command) {
            return Arrays.stream(values())
                    .filter(commandStrategy -> commandStrategy.code.equals(command))
                    .findFirst()
                    .orElseThrow();
        }

        public void move(Rover rover) {
            mover.accept(rover);
        }
    }

    private enum DirectionStrategy {
        NORTH("N",
                rover -> rover.y++,
                rover -> rover.y--,
                rover -> rover.direction = "W",
                rover -> rover.direction = "E"),
        SOUTH("S",
                rover -> rover.y--,
                rover -> rover.y++,
                rover -> rover.direction = "E",
                rover -> rover.direction = "W"),
        WEST("W",
                rover -> rover.x--,
                rover -> rover.x++,
                rover -> rover.direction = "S",
                rover -> rover.direction = "N"
        ),
        EAST(
                "E",
                rover -> rover.x++,
                rover -> rover.x--,
                rover -> rover.direction = "N",
                rover -> rover.direction = "S"
        );

        private final String direction;
        private final Consumer<Rover> forwarder;
        private final Consumer<Rover> backwarder;
        private final Consumer<Rover> righter;
        private final Consumer<Rover> lefter;

        DirectionStrategy(
                String direction,
                Consumer<Rover> forwarder,
                Consumer<Rover> backwarder,
                Consumer<Rover> lefter,
                Consumer<Rover> righter) {
            this.direction = direction;
            this.forwarder = forwarder;
            this.backwarder = backwarder;
            this.righter = righter;
            this.lefter = lefter;
        }

        public static DirectionStrategy of(String direction) {
            return Arrays.stream(values())
                    .filter(directionStrategy -> directionStrategy.direction.equals(direction))
                    .findFirst()
                    .orElseThrow();
        }

        public void forward(Rover rover) {
            forwarder.accept(rover);
        }

        public void backward(Rover rover) {
            backwarder.accept(rover);
        }

        public void left(Rover rover) {
            lefter.accept(rover);
        }

        public void right(Rover rover) {
            righter.accept(rover);
        }
    }
}
