import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.assertj.core.api.Assertions;

public class RoverGlue {

    private String actualPosition;
    private Rover rover;

    @Given("rover is at position {int} {int} {word}")
    public void rover_is_at_position(int x, int y, String direction) {
        rover = new Rover(x, y, direction);
    }
    @When("user sends command {word}")
    public void user_sends_command(String command) {
        actualPosition = rover.move(command);
    }
    @Then("rover response is {int} {int} {word}")
    public void rover_response_is_s(int x, int y, String direction) {
        Assertions.assertThat(actualPosition).isEqualTo(String.format("%d %d %s",x,y,direction));
    }
}
