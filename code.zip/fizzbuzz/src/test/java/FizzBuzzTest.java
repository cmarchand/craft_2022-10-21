import org.assertj.core.api.Assertions;
import org.junit.Test;

public class FizzBuzzTest {

    @Test
    public void given_1_when_fizzBuzz_then_1() {
        // Given
        int input = 1;
        String expected = "1";
        checkAssertions(input, expected);
    }
    @Test
    public void given_2_when_fizzBuzz_then_2() {
        // Given
        int input = 2;
        String expected = "2";
        checkAssertions(input, expected);
    }
    @Test
    public void given_3_when_fizzBuzz_then_Fizz() {
        // Given
        int input = 3;
        String expected = "Fizz";
        checkAssertions(input, expected);
    }
    @Test
    public void given_5_when_fizzBuzz_then_Buzz() {
        // Given
        int input = 5;
        String expected = "Buzz";
        checkAssertions(input, expected);
    }
    @Test
    public void given_6_when_fizzBuzz_then_Fizz() {
        // Given
        int input = 6;
        String expected = "Fizz";
        checkAssertions(input, expected);
    }
    @Test
    public void given_10_when_fizzBuzz_then_Buzz() {
        // Given
        int input = 10;
        String expected = "Buzz";
        checkAssertions(input, expected);
    }
    @Test
    public void given_15_when_fizzBuzz_then_FizzBuzz() {
        // Given
        int input = 15;
        String expected = "FizzBuzz";
        checkAssertions(input, expected);
    }
    @Test
    public void given_30_when_fizzBuzz_then_FizzBuzz() {
        // Given
        int input = 30;
        String expected = "FizzBuzz";
        checkAssertions(input, expected);
    }
    private void checkAssertions(int input, String expected) {
        FizzBuzz fizzBuzz = new FizzBuzz();
        String actual = fizzBuzz.toFizzBuff(input);
        Assertions.assertThat(actual).isEqualTo(expected);
    }
}
