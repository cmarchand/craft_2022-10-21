public class FizzBuzz {

    public String toFizzBuff(int input) {
        if (isFizzBuzz(input)) return "FizzBuzz";
        else if (isFizz(input)) return "Fizz";
        else if (isBuzz(input)) return "Buzz";
        else return Integer.toString(input);
    }

    private boolean isFizzBuzz(int input) {
        return isFizz(input) && isBuzz(input);
    }

    private boolean isFizz(int input) {
        return input % 3 == 0;
    }

    private boolean isBuzz(int input) {
        return input % 5 == 0;
    }
}