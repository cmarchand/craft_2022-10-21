import org.assertj.core.api.Assertions;
import org.junit.Test;

public class RPNCalculatorTest {

    @Test
    public void given_1_should_return_1() {
        // Given
        String input = "1";
        int expected = 1;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_2_should_return_2() {
        // Given
        String input = "2";
        int expected = 2;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_3_should_return_3() {
        // Given
        String input = "3";
        int expected = 3;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_1_2_add_should_return_3() {
        // Given
        String input = "1 2 +";
        int expected = 3;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_1_1_add_should_return_2() {
        // Given
        String input = "1 1 +";
        int expected = 2;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_1_1_multiply_should_return_1() {
        // Given
        String input = "1 1 *";
        int expected = 1;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_1_2_multiply_should_return_2() {
        // Given
        String input = "1 2 *";
        int expected = 2;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_1_1_minus_should_return_0() {
        // Given
        String input = "1 1 -";
        int expected = 0;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_minus1_minus1_plus_should_return_minus2() {
        // Given
        String input = "-1 -1 +";
        int expected = -2;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_20_5_divide_should_return_4() {
        // Given
        String input = "20 5 /";
        int expected = 4;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_4_2_plus_3_minus_should_return_3() {
        // Given
        String input = "4 2 + 3 -";
        int expected = 3;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_4_2_4_plus_minus_should_return_minus_2() {
        // Given
        String input = "4 2 4 + -";
        int expected = -2;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_3_5_8_multiplication_7_plus_multiply_should_return_141() {
        // Given
        String input = "3 5 8 * 7 + *";
        int expected = 141;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_9_sqrt_should_return_3() {
        // Given
        String input = "9 SQRT";
        int expected = 3;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }    @Test
    public void given_5_8_1_4_2_MAX_should_return_8() {
        // Given
        String input = "5 8 1 4 2 MAX";
        int expected = 8;
        // When
        int actual = RPNCalculator.calculate(input);
        // Then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_20_0_divide_should_throw() {
        // Given
        String input = "20 0 /";
        // When
        Assertions
                .assertThatThrownBy(() -> RPNCalculator.calculate(input))
                .isInstanceOf(Exception.class);
    }

}
