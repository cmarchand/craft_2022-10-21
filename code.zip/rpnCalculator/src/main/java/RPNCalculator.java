import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;
import java.util.function.BiConsumer;

public class RPNCalculator {
    public static int calculate(String expression) {
        List<String> items = Arrays.asList(expression.split(" "));
        Deque<Integer> stack = new ArrayDeque<>();
        for (String item : items) {
            OperatorStrategy.of(item).calculate(stack, item);
        }
        return stack.pop();
    }

    private enum OperatorStrategy {
        ADDITION("+", (stack, item) -> stack.push(stack.pop() + stack.pop())),
        SOUSTRACTION("-", (stack, item) -> stack.push(-stack.pop() + stack.pop())),
        MULTIPLICATION("*", (stack, item) -> stack.push(stack.pop() * stack.pop())),
        DIVISION("/", (stack, item) -> {
            Integer operand2 = stack.pop();
            Integer operand1 = stack.pop();
            stack.push(operand1 / operand2);
        }),
        SQRT("SQRT", (stack, item) -> stack.push((int) Math.sqrt(stack.pop()))),
        MAX("MAX", (stack, item) -> {
            int result = stack.stream().mapToInt(Integer::intValue).max().getAsInt();
            stack.clear();
            stack.push(result);
        }),
        OTHER("", (stack, s) -> stack.push(Integer.parseInt(s)));

        private final String symbol;
        private final BiConsumer<Deque<Integer>, String> operator;

        OperatorStrategy(String symbol, BiConsumer<Deque<Integer>, String> operator) {
            this.symbol = symbol;
            this.operator = operator;
        }

        public static OperatorStrategy of(String operator) {
            return Arrays.stream(values())
                    .filter(operatorStrategy -> operator.equals(operatorStrategy.symbol))
                    .findFirst()
                    .orElse(OTHER);
        }

        public void calculate(Deque<Integer> stack, String item) {
            operator.accept(stack, item);
        }

    }
}
