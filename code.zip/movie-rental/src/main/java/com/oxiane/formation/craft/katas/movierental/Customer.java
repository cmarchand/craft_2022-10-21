package com.oxiane.formation.craft.katas.movierental;

import java.util.Arrays;
import java.util.Enumeration;
import java.util.Vector;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;

public class Customer {
    public static class Tape {

        private String _serialNumber;
        private Movie _movie;

        public Tape(String serialNumber, Movie movie) {
            _serialNumber = serialNumber;
            _movie = movie;
        }

        public Movie movie() {
            return _movie;
        }

        public String serialNumber() {
            return _serialNumber;
        }
    }


    public static class Rental {

        private Tape _tape;
        private int _daysRented;

        public Rental(Tape tape, int daysRented) {
            _tape = tape;
            _daysRented = daysRented;
        }

        public int daysRented() {
            return _daysRented;
        }

        public Tape tape() {
            return _tape;
        }
    }


    public class Movie {
        public static final int CHILDRENS = 2;
        public static final int REGULAR = 0;
        public static final int NEW_RELEASE = 1;

        private int _priceCode;
        private String _name;

        public Movie(String name, int priceCode) {
            _name = name;
            _priceCode = priceCode;
        }

        public int priceCode() {
            return _priceCode;
        }

        public String name() {
            return _name;
        }
    }


    private String _name;
    private Vector _rentals = new Vector();

    public Customer(String name) {
        _name = name;
    }

    public String statement() {
        return getReport();
    }

    private String getReport() {
        return getReportHeader() + getReportBody() + getReportFooter();
    }

    private String getReportFooter() {
        String result = "";
        double totalAmount = getTotalAmount();
        int frequentRenterPoints = getFrequentRenterPoints();
        result += "Amount owed is " + String.valueOf(totalAmount) + "\n";
        result += "You earned " + String.valueOf(frequentRenterPoints) + " frequent renter points";
        return result;
    }

    private String getReportHeader() {
        String result = "Rental Record for " + name() + "\n";
        return result;
    }

    private String getReportBody() {
        String result = "";
        Enumeration rentals;
        rentals = _rentals.elements();
        while (rentals.hasMoreElements()) {
            Rental each = (Rental) rentals.nextElement();
            result += "\t" + each.tape().movie().name() + "\t" + String.valueOf(getRentalAmount(each)) + "\n";
        }
        return result;
    }

    private int getFrequentRenterPoints() {
        Enumeration rentals;
        int frequentRenterPoints = 0;
        rentals = _rentals.elements();
        while (rentals.hasMoreElements()) {
            Rental rental = (Rental) rentals.nextElement();
            frequentRenterPoints += MovieTypeStrategy.of(rental).calculateFrequentRenterPoints(rental);
        }
        return frequentRenterPoints;
    }

    private double getTotalAmount() {
        Enumeration rentals = _rentals.elements();
        double totalAmount = 0;
        while (rentals.hasMoreElements()) {
            Rental each = (Rental) rentals.nextElement();
            double thisAmount = getRentalAmount(each);
            totalAmount += thisAmount;
        }
        return totalAmount;
    }

    private double getRentalAmount(Rental rental) {
        return MovieTypeStrategy.of(rental).calculateRentalAmount(rental);
    }

    private String name() {
        return _name;
    }

    public void addRental(Rental arg) {
        _rentals.addElement(arg);
    }

    private enum MovieTypeStrategy {
        NEW_RELEASE(Movie.NEW_RELEASE, value -> value.daysRented() * 3, value -> value.daysRented() > 1 ? 2 : 1),
        REGULAR(Movie.REGULAR, rental -> { double result = 2;
            if (rental.daysRented() > 2)
                result += (rental.daysRented() - 2) * 1.5;
            return result;
        }, value -> 1),
        CHILDRENS(Movie.CHILDRENS, rental -> {
            double result  = 1.5;
            if (rental.daysRented() > 3)
                result += (rental.daysRented() - 3) * 1.5;
            return result;
        }, value -> 1)
        ;

        private final int priceCode;
        private final ToDoubleFunction<Rental> amountCalculator;
        private final ToIntFunction<Rental> frequentRenterPointsCalculator;

        MovieTypeStrategy(int priceCode, ToDoubleFunction<Rental> amountCalculator, ToIntFunction<Rental> frequentRenterPointsCalculator) {
            this.priceCode = priceCode;
            this.amountCalculator = amountCalculator;
            this.frequentRenterPointsCalculator = frequentRenterPointsCalculator;
        }

        public static MovieTypeStrategy of(Rental rental) {
            return Arrays.stream(values())
                    .filter(movieTypeStrategy -> rental.tape().movie().priceCode() == movieTypeStrategy.priceCode)
                    .findFirst()
                    .orElseThrow();
        }

        public double calculateRentalAmount(Rental rental) {
            return amountCalculator.applyAsDouble(rental);
        }

        public int calculateFrequentRenterPoints(Rental rental) {
            return frequentRenterPointsCalculator.applyAsInt(rental);
        }
    }
}
