import com.oxiane.formation.craft.katas.movierental.Customer;
import org.assertj.core.api.Assertions;
import org.junit.Test;

public class CustomerTest {
    @Test
    public void given_customer_without_rental_when_statement_then_0_0(){
        //Given
        Customer customer= new Customer("Tantely");
        String expected ="Rental Record for Tantely\n" +
                "Amount owed is 0.0\n" +
                "You earned 0 frequent renter points";
        //then
        String actual = customer.statement();
        //then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_customer_with_new_release_one_day_when_statement_then_3_1(){
        //Given
        Customer customer= new Customer("Tantely");
        Customer.Movie movie = customer.new Movie("Beast", Customer.Movie.NEW_RELEASE);
        Customer.Tape tape = new Customer.Tape("SR1452", movie);
        Customer.Rental rental = new Customer.Rental(tape,1);
        customer.addRental(rental);
        String expected ="Rental Record for Tantely\n" +
                "\tBeast\t3.0\n" +
                "Amount owed is 3.0\n" +
                "You earned 1 frequent renter points";
        //then
        String actual = customer.statement();
        //then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_customer_with_new_release_two_days_when_statement_then_6_2(){
        //Given
        Customer customer= new Customer("Tantely");
        Customer.Movie movie = customer.new Movie("Beast", Customer.Movie.NEW_RELEASE);
        Customer.Tape tape = new Customer.Tape("SR1452", movie);
        Customer.Rental rental = new Customer.Rental(tape,2);
        customer.addRental(rental);
        String expected ="Rental Record for Tantely\n" +
                "\tBeast\t6.0\n" +
                "Amount owed is 6.0\n" +
                "You earned 2 frequent renter points";
        //then
        String actual = customer.statement();
        //then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_customer_with_regular_one_day_when_statement_then_2_2(){
        //Given
        Customer customer= new Customer("Tantely");
        Customer.Movie movie = customer.new Movie("Titanic", Customer.Movie.REGULAR);
        Customer.Tape tape = new Customer.Tape("SR1452", movie);
        Customer.Rental rental = new Customer.Rental(tape,1);
        customer.addRental(rental);
        String expected ="Rental Record for Tantely\n" +
                "\tTitanic\t2.0\n" +
                "Amount owed is 2.0\n" +
                "You earned 1 frequent renter points";
        //then
        String actual = customer.statement();
        //then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_customer_with_regular_three_day_when_statement_then_3_1(){
        //Given
        Customer customer= new Customer("Tantely");
        Customer.Movie movie = customer.new Movie("Titanic", Customer.Movie.REGULAR);
        Customer.Tape tape = new Customer.Tape("SR1452", movie);
        Customer.Rental rental = new Customer.Rental(tape,3);
        customer.addRental(rental);
        String expected ="Rental Record for Tantely\n" +
                "\tTitanic\t3.5\n" +
                "Amount owed is 3.5\n" +
                "You earned 1 frequent renter points";
        //then
        String actual = customer.statement();
        //then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_customer_with_children_one_day_when_statement_then_15_15(){
        //Given
        Customer customer= new Customer("Tantely");
        Customer.Movie movie = customer.new Movie("Shrek", Customer.Movie.CHILDRENS);
        Customer.Tape tape = new Customer.Tape("SR47452", movie);
        Customer.Rental rental = new Customer.Rental(tape,1);
        customer.addRental(rental);
        String expected ="Rental Record for Tantely\n" +
                "\tShrek\t1.5\n" +
                "Amount owed is 1.5\n" +
                "You earned 1 frequent renter points";
        //then
        String actual = customer.statement();
        //then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
    @Test
    public void given_customer_with_children_4_days_when_statement_then_3_3(){
        //Given
        Customer customer= new Customer("Tantely");
        Customer.Movie movie = customer.new Movie("Shrek", Customer.Movie.CHILDRENS);
        Customer.Tape tape = new Customer.Tape("SR47452", movie);
        Customer.Rental rental = new Customer.Rental(tape,4);
        customer.addRental(rental);
        String expected ="Rental Record for Tantely\n" +
                "\tShrek\t3.0\n" +
                "Amount owed is 3.0\n" +
                "You earned 1 frequent renter points";
        //then
        String actual = customer.statement();
        //then
        Assertions.assertThat(actual).isEqualTo(expected);
    }
}
